﻿var http = require('http');

var server = http.Server();

server.on('request', function (req, res) {
    res.writeHead(200, { 'content-Type': 'text/html' });
    //res.setHeader("Set-Cookie", ["type=ninja", "language=javascript"]);

    res.write('<hl> nodejs </h1>')
    res.end('<p> Hello World </p>');
});

server.listen(3000, '171.0.0.1');
console.log("server run at http://172.0.0.1:3000");


